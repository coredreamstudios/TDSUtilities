#include "BaseWindow.h"
#pragma once


// Our simple custom button control (where the hard work is done! uses GDI+)
class GlassButton : public BaseWindow // by Napalm
{
	private:
		// Private class variables
		BOOL          m_bCacheDirty, m_bMouseTrack, m_bMouseHover, m_bMouseDown;
		CachedBitmap *m_pCachePaint;
		FLOAT         m_fGlowLevel;
		UINT          m_uGlowTimer;
		ARGB          m_argbGlow;
		
	public:
		// Constructor
		GlassButton(HINSTANCE hInst) : BaseWindow(hInst)
		{
			// Setup BaseWindow with our defaults ready for the first call to Create(...)
			m_wcexClass.hInstance     = hInst;

			// We set the redraw styles because the whole button needs to be redrawn if resized
			m_wcexClass.style         = CS_PARENTDC | CS_VREDRAW | CS_HREDRAW;
			m_wcexClass.lpszClassName = TEXT("GlassButton");

			// We have chosen to use NULL so that a background is not painted
			m_wcexClass.hbrBackground = NULL;

			m_dwStyle                 = WS_CHILD | WS_TABSTOP | WS_VISIBLE;
			m_dwExStyle               = 0;

			// Setup class variables with default values
			m_pCachePaint = NULL;
			m_bCacheDirty = TRUE;
			m_bMouseTrack = m_bMouseHover = m_bMouseDown  = FALSE;
			m_fGlowLevel  = 0;
			m_uGlowTimer  = 0;
			m_argbGlow    = 0xB28DBDFF;
		}
		
		// De-constructor
		~GlassButton()
		{
			//
		}
		
		// Property setter for Glow Color
		ARGB SetGlowColor(ARGB argbColor)
		{
			ARGB argbOld = m_argbGlow;
			m_argbGlow = argbColor;
			return argbOld;
		}
		
	private:
		// Handle incoming messages
		BOOL HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT *lResult)
		{
			// Pass each message on to the specific handlers
			switch(uMsg)
			{
				case WM_CREATE:
					*lResult = OnCreate((LPCREATESTRUCT)lParam);
					break;

				case WM_DESTROY:
					*lResult = OnDestroy();
					break;
					
				case WM_KEYDOWN:
					*lResult = OnKey(TRUE,  (INT)wParam, (INT)LOWORD(lParam));
					break;
					
				case WM_KEYUP:
					*lResult = OnKey(FALSE, (INT)wParam, (INT)LOWORD(lParam));
					break;
					
				case WM_LBUTTONDOWN:
					*lResult = OnMouseButton(TRUE,  GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
					break;

				case WM_LBUTTONUP:
					*lResult = OnMouseButton(FALSE, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
					break;

				case WM_MOUSEMOVE:
					*lResult = OnMouseMove((INT)wParam, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
					break;

				case WM_MOUSELEAVE:
					*lResult = OnMouseLeave();
					break;

				case WM_MOUSEHOVER:
					*lResult = OnMouseHover();
					break;

				case WM_SETFOCUS:
					*lResult = OnFocus(TRUE, (HWND)wParam);
					break;
					
				case WM_KILLFOCUS:
					*lResult = OnFocus(FALSE, (HWND)wParam);
					break;
					
				case WM_TIMER:
					*lResult = OnTimer((UINT)wParam);
					break;

				case WM_SIZE:
					*lResult = OnSize(LOWORD(lParam), HIWORD(lParam));
					break;
					
				case WM_GETDLGCODE:
					*lResult = DLGC_UNDEFPUSHBUTTON;
					break;
					
				default:
					return FALSE;
			}

			return TRUE;
		}


		// Window creation handler
		LRESULT OnCreate(LPCREATESTRUCT lpCreate)
		{
			// Because we have a NULL brush for the background we need to update the
			//   the display of our button on creation.
			SendMessage(m_hWnd, WM_SIZE, 0, 0);
			Redraw(TRUE);

			return 0;
		}

		// Window destruction handler
		LRESULT OnDestroy()
		{
			// Clean up allocated resources
			if(m_pCachePaint){
				delete m_pCachePaint;
				m_pCachePaint = NULL;
			}

			return 0;
		}

		// Handle the key down event
		LRESULT OnKey(BOOL bDown, INT nVirtKey, INT nRepeat)
		{
			// Forward the message on so that pressing space-bar will click the button
			if(nVirtKey == VK_SPACE)
				return OnMouseButton(bDown, 0, 0);

			return 0;
		}

		// Handle the mouse button event
		LRESULT OnMouseButton(BOOL bDown, INT nX, INT nY)
		{
			// Has the button push state changed?
			if(m_bMouseDown != bDown){
				// Was the mouse released over the button?
				if(m_bMouseDown && m_bMouseHover){
					PostMessage(GetParent(m_hWnd), WM_COMMAND,
						MAKELONG(GetWindowLong(m_hWnd, GWL_ID), BN_CLICKED), (LPARAM)m_hWnd);
				}
				// Set new state and redraw
				m_bMouseDown  = bDown;
				Redraw(TRUE);
			}

			return 0;
		}

		// Handle the mouse movement event
		LRESULT OnMouseMove(INT nKey, INT nX, INT nY)
		{
			// Track the mouse leaving our window
			if(!m_bMouseTrack){
				TRACKMOUSEEVENT tme = { sizeof(TRACKMOUSEEVENT), TME_LEAVE | TME_HOVER, m_hWnd, 1 };
				m_bMouseTrack = TrackMouseEvent(&tme);
			}
			// Update the hover
			if(!m_bMouseHover){
				// Reset the down state if needed
				if(nKey == MK_LBUTTON)
					m_bMouseDown = TRUE;
				m_bMouseHover = TRUE;
				Redraw(TRUE);
			}

			return 0;
		}

		// When the mouse leaves the window reset the state and redraw
		LRESULT OnMouseLeave()
		{
			m_bMouseHover = FALSE;
			m_bMouseTrack = FALSE;
			m_bMouseDown  = FALSE;
			Redraw(TRUE);
			
			// Update glow timer
			if(!m_uGlowTimer)
				m_uGlowTimer = SetTimer(m_hWnd, 1, 10, NULL);

			return 0;
		}

		// When the mouse hovers over the window set the state and redraw
		LRESULT OnMouseHover()
		{
			m_bMouseHover = TRUE;
			Redraw(TRUE);
			
			// Update glow timer
			if(!m_uGlowTimer)
				m_uGlowTimer = SetTimer(m_hWnd, 1, 10, NULL);

			return 0;
		}
		
		// Change the button state when we receive the keyboard focus (TAB key)
		LRESULT OnFocus(BOOL bHasFocus, HWND hWndLastFocus)
		{
			if(!bHasFocus)
				m_bMouseDown = FALSE;
			m_bMouseHover = bHasFocus;
			Redraw(FALSE);

			// Update glow timer
			if(!m_uGlowTimer)
				m_uGlowTimer = SetTimer(m_hWnd, 1, 10, NULL);
			
			return 1;
		}

		// This handles the timing on the glow effect
		LRESULT OnTimer(UINT uTimerID)
		{
			// Did we receive this timer message as a result of glow change?
			if(uTimerID == 1){
				// Increment the glow if mouse is over our button
				if(m_bMouseHover){
					m_fGlowLevel += 0.033f;
					if(m_fGlowLevel >= 1.0f){
						// When we reach the upper limit cancel the timer
						m_fGlowLevel = 1.0f;
						m_uGlowTimer = 0;
						KillTimer(m_hWnd, 1);
					}
					Redraw(FALSE);

				// Decrement the glow if the mouse is not over the button
				}else{
					m_fGlowLevel -= 0.066f;
					if(m_fGlowLevel <= 0.0f){
						// When we reach the bottom limit cancel the timer
						m_fGlowLevel = 0.0f;
						m_uGlowTimer = 0;
						KillTimer(m_hWnd, 1);
					}
					Redraw(FALSE);
				}
			}

			return 0;
		}

		// Update the window region based on the new size
		LRESULT OnSize(INT nWidth, INT nHeight)
		{
			Graphics graphics(m_hWnd);
			Rect rect(0, 0, m_rcClient.right, m_rcClient.bottom);
			GraphicsPath *gp = CreateRoundRectPath(rect, 24);
			SetWindowRgn(m_hWnd, Region(gp).GetHRGN(&graphics), FALSE);
			delete gp;
			
			Redraw(FALSE);
			
			return 0;
		}
		
		// Redraw our window
		BOOL Redraw(BOOL bUpdateNow)
		{
			m_bCacheDirty = TRUE;
			if(bUpdateNow)
				return RedrawWindow(m_hWnd, NULL, NULL, RDW_NOERASE | 
					RDW_INVALIDATE | RDW_UPDATENOW);
			else
				return InvalidateRect(m_hWnd, NULL, FALSE);;
		}

		// Lets paint our fancy window with alpha
		LRESULT OnPaint(PAINTSTRUCT *ps)
		{
			Graphics graphics(ps->hdc);

			// Do we need to redraw the window contents?
			if(m_bCacheDirty){
				// Create some GDI rect's
				Rect rect(m_rcClient.left, m_rcClient.top,
					m_rcClient.right, m_rcClient.bottom);
				RectF rectf ((float)m_rcClient.left, (float)m_rcClient.top,
					(float)m_rcClient.right, (float)m_rcClient.bottom);
				
				// Setup a double buffer for painting
				Bitmap *bmp = new Bitmap(m_rcClient.right, m_rcClient.bottom);
				Graphics *g = Graphics::FromImage(bmp);

				// Setup nicer graphics and copy in the background
				g->SetSmoothingMode(SmoothingModeAntiAlias);
				g->ReleaseHDC(PaintParentBackground(g->GetHDC()));

				// Draw double border of white and black
				Rect border = rect;
				border.Inflate(-2, -2);
				DrawRoundRect(g, border, Color::White, 12);
				border.Inflate(-1, -1);
				DrawRoundRect(g, border, Color::Black, 12);
				
				// Create a path for us to work inside the borders
				GraphicsPath *innerPath = CreateRoundRectPath(border, 12);
				
				// Fill in the semi-transparent background depending on button state
				SolidBrush background(Color((m_bMouseDown) ? 0xCC000000 : 0x7F000000));
				g->FillPath(&background, innerPath);
				
				// Clip further painting operations to inside the border
				g->SetClip(innerPath);
				
				// Choose the shine colors depending on button state
				Color colorShine1, colorShine2;
				if(m_bMouseDown){
					colorShine1.SetValue(0x3DFFFFFF), colorShine2.SetValue(0x14FFFFFF);
				}else{
					colorShine1.SetValue(0x99FFFFFF), colorShine2.SetValue(0x33FFFFFF);
				}

				// Add the button shine effect to the button
				Rect shine = border;
				shine.Height /= 2;
				LinearGradientBrush shineBrush(shine, colorShine1,
					colorShine2, LinearGradientModeVertical);
				g->FillRectangle(&shineBrush, shine);
				
				// If the button is not pushed down?
				if(!m_bMouseDown){
					// Calculate the alpha level for the glow color
					ARGB argbGlowStart, argbGlowEnd;
					argbGlowStart  = argbGlowEnd = (m_argbGlow & ~Color::AlphaMask);
					argbGlowStart |= ((ARGB)(BYTE)(((m_argbGlow &  Color::AlphaMask) >> 
						Color::AlphaShift) * m_fGlowLevel) << Color::AlphaShift);
					
					// Paint the glow starting from bottom center
					PathGradientBrush pgb(innerPath);
					Color colorGlowEnd(argbGlowEnd);
					int colorCount = 1;
					pgb.SetCenterColor(Color(argbGlowStart));
					pgb.SetSurroundColors(&colorGlowEnd, &colorCount);
					pgb.SetCenterPoint(PointF(rectf.Width * 0.50f, rectf.Height * 1.00f));
					g->FillPath(&pgb, innerPath);
				}

				// Get the buttons text length
				int nTextLen = GetWindowTextLength(m_hWnd);

				// Is there text to paint?
				if(nTextLen > 0){
					// Get the buttons text
					LPWSTR lpwsText = new WCHAR[++nTextLen];
					if(lpwsText){
						GetWindowTextW(m_hWnd, lpwsText, nTextLen);

						// Position the text in the center of the button
						StringFormat strFormat;
						strFormat.SetAlignment(StringAlignmentCenter);
						strFormat.SetLineAlignment(StringAlignmentCenter);
						
						// Setup the style and draw the text
						SolidBrush textColor(Color::White);
						Font buttonFont(L"Arial", 12, FontStyleRegular, UnitPixel);
						g->DrawString(lpwsText, -1, &buttonFont, rectf, &strFormat, &textColor);

						// Free the button text
						delete lpwsText;
					}
				}

				// Reset the clipping area and delete the clip path
				g->ResetClip();
				delete innerPath;

				// Update our cached bitmap
				if(m_pCachePaint) delete m_pCachePaint;
				m_pCachePaint = new CachedBitmap(bmp, &graphics);
				
				// Free resources and reset the state
				delete bmp;
				delete g;
				m_bCacheDirty = FALSE;
			}

			// Draw the final cached image to the screen
			graphics.DrawCachedBitmap(m_pCachePaint, 0, 0);

			return 0;
		}

		// Creates a rounded rectangle path with corner diameter d
		GraphicsPath *CreateRoundRectPath(Rect r, int d)
		{
			GraphicsPath *gp = new GraphicsPath();
			
			if(d > r.Width)  d = r.Width;
			if(d > r.Height) d = r.Height;
			
			Rect Corner(r.X, r.Y, d, d);
			
			gp->Reset();
			gp->AddArc(Corner, 180, 90);
			Corner.X += (r.Width - d - 1);
			gp->AddArc(Corner, 270, 90);
			Corner.Y += (r.Height - d - 1);
			gp->AddArc(Corner, 0, 90);
			Corner.X -= (r.Width - d - 1);
			gp->AddArc(Corner, 90, 90);
			gp->CloseFigure();
			
			return gp;
		}
		
		// Draw the edge of a rounded rectangle
		void DrawRoundRect(Graphics *g, Rect rect, Color color, INT nDiameter)
		{
			GraphicsPath *gp = CreateRoundRectPath(rect, nDiameter);
			Pen pen(color, 1);    
			pen.SetAlignment(PenAlignmentCenter);
			int oldPageUnit = g->SetPageUnit(UnitPixel);
			g->DrawPath(&pen, gp);
			g->SetPageUnit((Unit)oldPageUnit);
			delete gp;
		}
		
		// Copy the background of our window from the parent window
		HDC PaintParentBackground(HDC hdc)
		{
			POINT ptOrg;
			HRGN  hRgn;
			HWND  hWndParent  = GetParent(m_hWnd);
			RECT  rcTranslate = m_rcClient;
			
			// Map our client area to its position relative to the client area of the parent
			MapWindowPoints(m_hWnd, hWndParent, (LPPOINT)&rcTranslate, 2);
			SetWindowOrgEx(hdc, rcTranslate.left, rcTranslate.top, &ptOrg);
			
			// Clip painting to our client area's width and height
			hRgn = CreateRectRgnIndirect(&m_rcClient);
			SelectClipRgn(hdc, hRgn);
			DeleteObject(hRgn);
			
			// Tell the parent to paint to our HDC
			SendMessage(hWndParent, WM_PRINTCLIENT, (WPARAM)hdc, PRF_CLIENT);
			
			// Turn off the clipping limit
			SelectClipRgn(hdc, NULL);
			
			// Reset the coordinate translation
			SetWindowOrgEx(hdc, ptOrg.x, ptOrg.y, NULL);
			
			return hdc;
		}
		
};

