// Add the librarys to the linker
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "gdiplus.lib")

// Make sure we include XP compatible headers
#define _WIN32_WINNT	0x501

// Make sure we are supporting Unicode
#define UNICODE
#define _UNICODE

// Include only the headers we need
#include <windows.h>
#include <windowsx.h>
#include <olectl.h>
#include <ole2.h>
#include <gdiplus.h>

// Lets use GDI+ globally
using namespace Gdiplus;

// Load our resource identifiers
#include "resource.h"

