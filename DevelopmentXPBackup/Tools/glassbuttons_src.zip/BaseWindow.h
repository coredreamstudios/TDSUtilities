#include "Global.h"
#pragma once


// Our base window class which every window is derived from
class BaseWindow // by Napalm
{
	protected:
		// Protected class variables (only this class and derived classes can access)
		HWND       m_hWnd;
		HINSTANCE  m_hInst;
		WNDCLASSEX m_wcexClass;
		DWORD      m_dwStyle, m_dwExStyle;
		BOOL       m_bCreated;
		RECT       m_rcClient;

		// Message handler callback (must be overridden)
		virtual BOOL HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT *lResult) = 0;

		// Default paint handler (can be overridden)
		virtual LRESULT OnPaint(PAINTSTRUCT *ps) { return 0; };

	private:
		// Global function for window messages (this function exists outside the class)
		static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
		{
			// Get the class pointer when we receive a message
			BaseWindow *self = (BaseWindow *)GetWindowLong(hWnd, 0);
			LRESULT lResult = 0;
			
			// Set the class pointer on creation of the window
			if(uMsg == WM_NCCREATE){
				LPCREATESTRUCT lpCreate = (LPCREATESTRUCT)lParam;
				self = (BaseWindow *)lpCreate->lpCreateParams;
				SetWindowLong(hWnd, 0, (LONG)self);

				// Save hWnd ready for a PreHandleMessage
				lpCreate->lpCreateParams = (LPVOID)hWnd;
			}

			// Do we have a pointer?
			if(self){
				// Pre and Post handle the messages
				if(!self->PreHandleMessage(uMsg, wParam, lParam, &lResult))
					self->PostHandleMessage(uMsg, wParam, lParam, &lResult);

				// Keep a check on our creation response
				if(uMsg == WM_CREATE)
					self->m_bCreated = (lResult >= 0);

				return lResult;
			}else{
				// Oh dear! we must at least use the default handler
				return DefWindowProc(hWnd, uMsg, wParam, lParam);
			}
		}
		
		// Pre-handle messages to keep variables up to date (this function exists in the class)
		BOOL PreHandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT *lResult)
		{
			switch(uMsg)
			{
				case WM_NCCREATE:
					m_hWnd = (HWND)((LPCREATESTRUCT)lParam)->lpCreateParams;
					break;

				case WM_CREATE:
				case WM_SIZE:
					GetClientRect(m_hWnd, &m_rcClient);
					break;
			}

			// Forward message onto the derived class handler
			return HandleMessage(uMsg, wParam, lParam, lResult);
		}
		
		// Post-handle messages to use internal paint and default handlers
		BOOL PostHandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT *lResult)
		{
			switch(uMsg){
				case WM_PAINT:
					*lResult = OnInternalPaint(NULL);
					break;

				case WM_PRINTCLIENT:
					*lResult = OnInternalPaint((HDC)wParam);
					break;

				default:
					*lResult = DefWindowProc(m_hWnd, uMsg, wParam, lParam);
					break;
			}

			return TRUE;
		}

		// Default painting handler
		LRESULT OnInternalPaint(HDC hdc)
		{
			LRESULT lResult;
			PAINTSTRUCT ps;
			ZeroMemory(&ps, sizeof(ps));
			if(!hdc)
				BeginPaint(m_hWnd, &ps);
			else{
				CopyRect(&ps.rcPaint, &m_rcClient);
				ps.hdc = hdc;
			}
			lResult = OnPaint(&ps);
			if(!hdc)
				EndPaint(m_hWnd, &ps);

			return lResult;
		}

	public:
		// This can be used to access the protected window handle
		operator HWND() { return m_hWnd; }

		// Constructor
		BaseWindow(HINSTANCE hInst) : m_hWnd(NULL), m_hInst(hInst)
		{
			// Setup default class and window settings
			ZeroMemory(&m_wcexClass,  sizeof(m_wcexClass));
			m_wcexClass.cbSize      = sizeof(m_wcexClass);
			m_wcexClass.lpfnWndProc = BaseWindow::WndProc;
			m_wcexClass.cbWndExtra  = sizeof(LONG);
			m_wcexClass.hInstance   = hInst;
			m_wcexClass.hIcon       = LoadIcon(NULL, IDI_APPLICATION);
			m_wcexClass.hCursor     = LoadCursor(NULL, IDC_ARROW);
			m_dwStyle               = WS_OVERLAPPEDWINDOW;
			m_dwExStyle             = 0;
			m_bCreated              = FALSE;
		}
		
		// De-constructor (overridable)
		virtual ~BaseWindow()
		{
			// We want to make sure the window doesn't exist anymore
			if(IsWindowVisible(m_hWnd))
				DestroyWindow(m_hWnd);
		}
		
		// Window creation function (call this instead of CreateWindowEx)
		HWND Create(LPTSTR lpszText, WORD wID, INT nX, INT nY, INT nWidth, INT nHeight, HWND hWndParent)
		{
			// On first call register the class for the window
			if(!RegisterClassEx(&m_wcexClass)){
				WNDCLASSEX wcexTemp;
				// Check to see if we have already registered the class before
				if(!GetClassInfoEx(m_hInst, m_wcexClass.lpszClassName, &wcexTemp))
					return NULL;
			}

			// Return the new window handle
			return CreateWindowEx(m_dwExStyle, m_wcexClass.lpszClassName, lpszText, m_dwStyle,
				nX, nY, nWidth, nHeight, hWndParent, (HMENU)wID, m_hInst, (LPVOID)this);
		}

		// Default message pump (helper function)
		int MessagePump(INT nShowCmd, BOOL bModal)
		{
			MSG Msg;

			ShowWindow(m_hWnd, nShowCmd);
			UpdateWindow(m_hWnd);

			while(GetMessage(&Msg, (bModal ? m_hWnd : NULL), 0, 0) > 0)
			{
				TranslateMessage(&Msg);
				DispatchMessage(&Msg);
			}

			return (int)Msg.wParam;
		}

};
