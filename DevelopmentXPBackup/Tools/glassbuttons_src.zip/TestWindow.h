#include "BaseWindow.h"
#include "ResImage.h"
#include "GlassButton.h"
#pragma once


// Our main GUI window created in WinMain (uses only GDI)
class TestWindow : public BaseWindow // by Napalm
{
	private:
		// Private class variables
		ResImage    *m_riAeroGrass;
		GlassButton *m_gbButtons[2];
		LPTSTR       m_lpszMessage;
		HFONT        m_hfArial;

	public:
		// Constructor
		TestWindow(HINSTANCE hInst) : BaseWindow(hInst)
		{
			// Setup BaseWindow with our defaults ready for the first call to Create(...)
			m_wcexClass.hInstance     = hInst;
			m_wcexClass.style         = CS_SAVEBITS;
			m_wcexClass.lpszClassName = TEXT("TestWindow");
			m_wcexClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
			m_dwStyle                 = WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN;
			m_dwExStyle               = WS_EX_APPWINDOW | WS_EX_CONTROLPARENT;

			// Setup class variables with default values
			m_riAeroGrass  = NULL;
			m_gbButtons[0] = NULL;
			m_gbButtons[1] = NULL;
			m_lpszMessage  = TEXT("Please push a button...");
			m_hfArial      = NULL;
		}

		// De-constructor
		~TestWindow()
		{
			//
		}
		
	private:
		// Handle incoming messages
		BOOL HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT *lResult)
		{
			// Pass each message on to the specific handlers
			switch(uMsg)
			{
				case WM_CREATE:
					*lResult = OnCreate((LPCREATESTRUCT)lParam);
					break;

				case WM_NCDESTROY:
					*lResult = OnNcDestroy();
					break;

				case WM_LBUTTONDOWN:
					*lResult = OnMouseButton(TRUE,  (INT)wParam, (INT)LOWORD(lParam));
					break;
					
				case WM_COMMAND:
					*lResult = OnCommand((HWND)lParam, LOWORD(wParam), HIWORD(wParam));
					break;

				case WM_SIZE:
					*lResult = OnSize(LOWORD(lParam), HIWORD(lParam));
					break;

				case WM_CLOSE:
					*lResult = OnClose();
					break;

				case WM_ERASEBKGND:
					*lResult = 1;
					break;
					
				default:
					return FALSE;
			}

			return TRUE;
		}
		
		// Window creation handler
		LRESULT OnCreate(LPCREATESTRUCT lpCreate)
		{
			// Create a few test instance's of our GlassButton
			m_gbButtons[0] = new GlassButton(m_hInst);
			if(!m_gbButtons[0] || !m_gbButtons[0]->Create(TEXT("First Button"),
					IDC_FIRSTBTN, 0, 0, 0, 0, m_hWnd))
				return -1;
			m_gbButtons[1] = new GlassButton(m_hInst);
			if(!m_gbButtons[1] || !m_gbButtons[1]->Create(TEXT("Second Button"),
					IDC_SECONDBTN, 0, 0, 0, 0, m_hWnd))
				return -1;

			// Set second buttons glow color to red
			m_gbButtons[1]->SetGlowColor(0xB2CC0000);
			
			// Load background JPEG from resource
			m_riAeroGrass = new ResImage(m_hInst, MAKEINTRESOURCE(IDR_AEROGRASSIMG), RT_RCDATA);
			if(!m_riAeroGrass)
				return -1;

			// Create GDI font handle: [11pt Arial Italic Anti-aliased]
			HDC hdc = GetDC(m_hWnd);
			LOGFONT lfArial = {
				-MulDiv(10, GetDeviceCaps(hdc, LOGPIXELSY), 72), 0, 0, 0,
				FW_MEDIUM, 0, 0, 0, 0, 0, 0, CLEARTYPE_QUALITY, 0, TEXT("Arial")
			};
			m_hfArial = CreateFontIndirect(&lfArial);
			ReleaseDC(m_hWnd, hdc);
			
			return 0;
		}
		
		// Window non-client destruction handler (last message to the window)
		LRESULT OnNcDestroy()
		{
			// Clean up and exit the message pump
			if(m_gbButtons[0]) delete m_gbButtons[0];
			if(m_gbButtons[1]) delete m_gbButtons[1];
			if(m_riAeroGrass)  delete m_riAeroGrass;
			if(m_hfArial)      DeleteObject(m_hfArial);
			
			// Only post a quit message if we were successfully created
			if(m_bCreated)
				PostQuitMessage(0);
			
			return 0;
		}

		// Handle the mouse button event
		LRESULT OnMouseButton(BOOL bDown, INT nX, INT nY)
		{
			m_lpszMessage  = TEXT("Please push a button...");
			InvalidateRect(m_hWnd, NULL, FALSE);

			return 0;
		}

		// Window command handler (we receive notification form controls here)
		LRESULT OnCommand(HWND hWndCtrl, WORD wID, WORD wCode)
		{
			// Was the message from a button click?
			if(wCode == BN_CLICKED){
				switch(wID)
				{
					case IDC_FIRSTBTN:  m_lpszMessage = TEXT("... first button clicked!");  break;
					case IDC_SECONDBTN: m_lpszMessage = TEXT("... second button clicked!"); break;
				}
				InvalidateRect(m_hWnd, NULL, FALSE);
			}

			return 0;
		}
		
		// Window size handler (update the control positions here)
		LRESULT OnSize(WORD wWidth, WORD wHeight)
		{
			// Calculate button size
			RECT rc = m_rcClient;
			InflateRect(&rc, (int)(m_rcClient.right * -0.33f), (int)(m_rcClient.bottom * -0.40f));

			// Set the first button's position
			OffsetRect(&rc, 0, -(rc.bottom - rc.top));
			MoveWindow(*m_gbButtons[0], rc.left, rc.top, (rc.right - rc.left), (rc.bottom - rc.top), FALSE);

			// Set the second button's position
			OffsetRect(&rc, 0, (rc.bottom - rc.top) * 2);
			MoveWindow(*m_gbButtons[1], rc.left, rc.top, (rc.right - rc.left), (rc.bottom - rc.top), FALSE);

			// Redraw everything
			RedrawWindow(m_hWnd, NULL, NULL, RDW_NOERASE |
				RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_UPDATENOW);

			return 0;
		}
		
		// Window painting handler
		LRESULT OnPaint(PAINTSTRUCT *ps)
		{
			// Stretch our JPEG across the window background
			SetStretchBltMode(ps->hdc, HALFTONE);
			StretchBlt(ps->hdc, 0, 0, m_rcClient.right, m_rcClient.bottom,
				*m_riAeroGrass, 0, 0, m_riAeroGrass->Width(), m_riAeroGrass->Height(), SRCCOPY);

			// Select the Arial font into our HDC and save the old selected font
			// Note: This is important because the HDC should be in its original
			//       state when it gets destroyed.
			HFONT hfOld = SelectFont(ps->hdc, m_hfArial);
			SetBkMode(ps->hdc, TRANSPARENT);
			
			// Show button click status in center of window
			RECT rcTextRect = m_rcClient;
			OffsetRect(&rcTextRect,  1,  1);
			SetTextColor(ps->hdc, RGB(  0,   0,   0));
			DrawText(ps->hdc, m_lpszMessage, -1, &rcTextRect, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
			OffsetRect(&rcTextRect, -1, -1);
			SetTextColor(ps->hdc, RGB(255, 255, 255));
			DrawText(ps->hdc, m_lpszMessage, -1, &rcTextRect, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
			
			// Select the old font back into the HDC
			SelectObject(ps->hdc, hfOld);
			
			return 0;
		}

		// Window close handler
		LRESULT OnClose()
		{
			AnimateWindow(m_hWnd, 500, AW_SLIDE | AW_VER_POSITIVE | AW_HIDE);
			DestroyWindow(m_hWnd);
			return 0;
		}
		
};