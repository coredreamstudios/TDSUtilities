#include "Global.h"
#include "TestWindow.h"

/*
  
  Glass Button Example GUI Application - by Napalm
  ================================================
  This example will show you how to do the follow:
  
    + Using C++ classes to derive a base where GUI interactions can be made simple.
	+ Implementing the windows GDI+ library for nicer graphics.
	+ A lot more, I would guess :)
  
*/

// Program entry-point
int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmdLine, int nShowCmd)
{
	MSG msgPump;
	ULONG_PTR gdiplusToken;
	GdiplusStartupInput gdiplusStartupInput;

	// Try and start up the GDI+ library
	if(GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL) != Ok)
	{
		return MessageBox(HWND_DESKTOP, TEXT("Cannot start the GDI+ library!"),
			TEXT("GlassButtons Error"), MB_ICONERROR | MB_OK);
	}
	
	// Calculate our starting position and size
	int nScreenX = GetSystemMetrics(SM_CXSCREEN), nScreenY = GetSystemMetrics(SM_CYSCREEN);
	int nWidth   = (int)(nScreenX * 0.33f), nHeight  = (int)(nScreenY * 0.25f);
	RECT rc = { (nScreenX - nWidth) / 2, (nScreenY - nHeight) / 2, nWidth, nHeight };
	
	// Create our main GUI window instance
	TestWindow *testWindow = new TestWindow(hInst);
	if(!testWindow || !testWindow->Create(TEXT("Glass Button Example - by Napalm"), 0,
		rc.left, rc.top, rc.right, rc.bottom, HWND_DESKTOP))
	{
		return MessageBox(HWND_DESKTOP, TEXT("Cannot create main window!"),
			TEXT("GlassButtons Error"), MB_ICONERROR | MB_OK);
	}

	// Display the window
	SendMessage(*testWindow, WM_SIZE, 0, 0);
	AnimateWindow(*testWindow, 700, AW_BLEND);
	SetForegroundWindow(*testWindow);

	// Pump for messages
	while(GetMessage(&msgPump, NULL, 0, 0) > 0)
	{
		// We use this message to process the TAB key
		if(!IsDialogMessage(*testWindow, &msgPump)){
			TranslateMessage(&msgPump);
			DispatchMessage(&msgPump);
		}
	}
	
	// Clean up and return result
	delete testWindow;
	GdiplusShutdown(gdiplusToken);

	return (int)msgPump.wParam;
}
