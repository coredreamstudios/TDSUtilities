Title: Flash button in VB forms
Description: This sample app demonstrate how to use the designed button constructed under Flash and incorporated it with vb6
in a way that such button shall behave the way a vb6 normal button does (Click Event in this example).
Please vote..thanks.
In this way we shall be able to add more better look for the interface which we would think would only be applicable
on the web browsers. by default, shockwave control add-in in vb application does not support click event.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59002&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
